package Assignments.rabbits.lastname.src;

public class MainRabbit {

    public static void main(String[] args) {
        RabbitsGrassSimulationModel.main(args);
    }

}